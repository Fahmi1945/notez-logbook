# NOTEZ Logbook - Frontend

Aplikasi frontend untuk NOTEZ Logbook, sebuah platform mentoring dan pencatatan (logbook) berkala bagi mahasiswa dan mentor. Proyek ini dibangun menggunakan **Next.js (App Router)** dan **Tailwind CSS**.

## Fitur Utama

- **Otentikasi & Otorisasi**: Login dan registrasi dengan role `user` (mahasiswa) dan `mentor`.
- **Dasbor Personal**: Tampilan dashboard yang menyesuaikan peran pengguna.
- **Manajemen Logbook**: Mahasiswa dapat mencatat, mengedit, dan melihat riwayat entri logbook.
- **Sistem Mentoring**: Mahasiswa dapat mengajukan bimbingan (request mentor), sedangkan mentor dapat menyetujui, meninjau logbook, dan memantau mahasiswa bimbingannya.
- **Notifikasi**: Pembaruan status persetujuan, tugas, dan aktivitas.
- **Laporan & Ekspor**: Mengekspor data logbook menjadi dokumen PDF.

## Tech Stack

- **Framework**: [Next.js 16+](https://nextjs.org/) (App Router)
- **Styling**: [Tailwind CSS](https://tailwindcss.com/)
- **State Management**: [Zustand](https://zustand-demo.pmnd.rs/)
- **HTTP Client**: [Axios](https://axios-http.com/)
- **Validasi**: [Zod](https://zod.dev/)

## Struktur Folder Frontend

Struktur direktori utama di dalam proyek ini didesain agar rapi dan terukur:

```text
frontend/
	.env.example
	AGENTS.md
	ARSITEKTUR.md
	CLAUDE.md
	next.config.ts
	package.json
	src/
		middleware.ts          # Guard route berbasis token JWT
		app/                   # App Router pages & layouts
			(auth)/            # Route group publik (login/register)
			(user)/            # Route group proteksi untuk role 'user'
			mentor/            # Route direktori untuk role 'mentor'
			globals.css        # CSS global & design token
		components/            # UI dan Feature-specific components
			auth/
			dashboard/
			layout/
			logbook/
			mentorship/
			review/
			ui/                # Shared generic UI components
		config/
		hooks/                 # Custom React hooks
		lib/                   # Utilities, Axios instances, Zod schemas
		store/                 # Zustand store (global state)
		types/                 # TypeScript interfaces
```

*(Untuk detail lebih lengkap, arsitektur, dan tabel rute, silakan periksa file `ARSITEKTUR.md`)*

## Persiapan Pengembangan (Getting Started)

1. **Instal Dependensi**:
   ```bash
   npm install
   # atau
   yarn install
   # atau
   pnpm install
   ```

2. **Pengaturan Environment Variables**:
   Salin file `.env.example` menjadi `.env` (atau `.env.local`) dan sesuaikan nilainya:
   ```bash
   cp .env.example .env.local
   ```
   *Isi parameter yang diperlukan, termasuk `NEXT_PUBLIC_API_URL` ke alamat backend API Anda.*

3. **Jalankan Server Development**:
   ```bash
   npm run dev
   # atau
   yarn dev
   # atau
   pnpm dev
   ```

4. **Akses Aplikasi**:
   Buka [http://localhost:3000](http://localhost:3000) di browser untuk melihat antarmuka aplikasi.

## Catatan Tambahan Pengembangan

- **Design Guidelines**: Aplikasi dirancang dengan desain yang clean, menggunakan warna netral (slate) dengan aksen warna institusional (ink-blue). Komponen responsif menggunakan utility class dari Tailwind.
- **Development Vibe**: Selalu baca `AGENTS.md` dan `CLAUDE.md` untuk pedoman lebih lanjut. Hal ini penting saat Anda menggunakan bantuan AI Assistant (Copilot, Claude, dsb.) agar usulan kode selalu konsisten dengan arsitektur proyek.
