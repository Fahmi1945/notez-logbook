"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";

interface PdfViewerProps {
  url: string;
  title: string;
}

export function PdfViewer({ url, title }: PdfViewerProps) {
  const [error, setError] = useState(false);

  return (
    <div className="flex flex-col h-full bg-gray-50 rounded-2xl overflow-hidden border border-gray-200">
      <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-gray-200">
        <h4 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-rose-500"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><path d="M8 13h2"/><path d="M8 17h2"/><path d="M14 13h2"/><path d="M14 17h2"/></svg>
          <span className="truncate max-w-[200px] sm:max-w-xs">{title}</span>
        </h4>
        <Button variant="outline" size="sm" onClick={() => window.open(url, "_blank")} className="text-xs h-8">
          Buka di Tab Baru
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2"><path d="M21 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h6"/><path d="m21 3-9 9"/><path d="M15 3h6v6"/></svg>
        </Button>
      </div>
      
      <div className="flex-1 w-full h-[600px] relative">
        {!error ? (
          <iframe 
            src={`${url}#toolbar=0`} 
            className="w-full h-full"
            title={title}
            onError={() => setError(true)}
          />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-gray-500 bg-gray-50 p-6 text-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mb-4 text-gray-300"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>
            <p className="font-medium text-gray-700">Gagal memuat pratinjau dokumen.</p>
            <p className="text-sm text-gray-400 mt-1 mb-4 max-w-sm">Browser Anda mungkin tidak mendukung pratinjau PDF langsung di dalam halaman.</p>
            <Button variant="primary" onClick={() => window.open(url, "_blank")}>
              Unduh atau Buka Langsung
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
