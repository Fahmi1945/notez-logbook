"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ReviewStatus } from "@/lib/api/mentor-review";
import { useUIStore } from "@/store/ui-store";

interface ReviewFormProps {
  logbookId: number;
  submitReview: (status: ReviewStatus, comment?: string) => Promise<any>;
  isProcessing: boolean;
  onSuccess?: () => void;
}

export function ReviewForm({ logbookId, submitReview, isProcessing, onSuccess }: ReviewFormProps) {
  const [note, setNote] = useState("");
  const { showToast } = useUIStore();

  const handleSubmit = async (action: "approved" | "rejected") => {
    if (action === "rejected" && !note.trim()) {
      showToast("Catatan wajib diisi jika menolak logbook.", "error");
      return;
    }

    try {
      await submitReview(action, note);
      if (onSuccess) onSuccess();
    } catch (error) {
      // Error sudah di-handle oleh useReviewDetail, tapi kita tangkap agar tidak bubar
      console.error(error);
    }
  };

  return (
    <div className="space-y-5">
      <Textarea
        label="Catatan Review (Opsional jika Setuju, Wajib jika Tolak)"
        placeholder="Berikan masukan, pujian, atau alasan penolakan di sini..."
        value={note}
        onChange={(e) => setNote(e.target.value)}
        rows={4}
        disabled={isProcessing}
      />
      
      <div className="flex flex-col sm:flex-row gap-3 pt-2">
        <Button 
          variant="danger" 
          className="flex-1 order-2 sm:order-1 bg-white border-2 border-rose-500 !text-rose-600 hover:bg-rose-50 hover:!text-rose-700 shadow-none"
          onClick={() => handleSubmit("rejected")}
          disabled={isProcessing}
          isLoading={isProcessing}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
          Tolak
        </Button>
        <Button 
          variant="primary" 
          className="flex-[2] order-1 sm:order-2 !bg-emerald-600 hover:!bg-emerald-700 focus:ring-emerald-600 shadow-emerald-600/20 shadow-lg"
          onClick={() => handleSubmit("approved")}
          disabled={isProcessing}
          isLoading={isProcessing}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><path d="M20 6 9 17l-5-5"/></svg>
          Setujui Logbook
        </Button>
      </div>
    </div>
  );
}
