# Panduan Khusus Claude / AI Assistant (Konteks Proyek)

File ini memberikan panduan cepat bagi AI Assistant (terutama Claude, Cursor, atau platform serupa) mengenai **coding vibe**, ekspektasi arsitektur, dan cara pemecahan masalah di proyek NOTEZ Frontend.

## Vibe & Konteks Utama

1. **Mental Model: Modern Next.js (App Router)**
   Proyek ini dibangun di atas App Router Next.js 16+. Secara default, file-file di dalam `src/app/` adalah **Server Components**. JANGAN sembarangan mengubah layout atau halaman utama (page.tsx) menjadi Client Component dengan `"use client"` kecuali sangat mendesak. Sebisa mungkin, ekstrak saja bagian yang interaktif (mis. form login, tombol interaktif) menjadi komponen anak di `src/components/` lalu import komponen tersebut.

2. **Wajib Membaca `ARSITEKTUR.md`**
   Sebelum membuat fitur baru, struktur layout baru, atau merekomendasikan rute URL apa pun, periksa file `ARSITEKTUR.md`. File itu merupakan pedoman wajib mengenai pembagian rute, guard folder `(auth)` vs `(user)` vs `mentor/`, dan otorisasi. Jangan merusak arsitektur tersebut!

3. **Styling yang Elegan & Seragam**
   Kita memakai Tailwind CSS murni dengan panduan design token. Kita tidak memakai UI Library yang berat.
   - Pengecekan pertama: Cari dan manfaatkan komponen UI generik di `src/components/ui/` (seperti Card, Button, Badge).
   - Patuhi palet warna: Desain harus terlihat layaknya platform akademik/institusional modern. Gunakan palet slate/netral untuk base dan background, dengan sentuhan warna primer (ink-blue) untuk elemen interaktif (lihat `globals.css`). Desain harus clean, tidak mencolok/lebay, responsif, berfokus pada ruang kosong (whitespace) dan keterbacaan tipografi.

4. **Keseragaman State, Validasi & API**
   - **Form & Payload**: Pastikan validasi form selalu di-handle menggunakan Zod di layer `src/lib/validators`. Gabungkan dengan React Hook Form jika butuh untuk sisi klien.
   - **State Global**: Gunakan Zustand (di `src/store`). JANGAN implementasikan Context API atau Redux untuk state kompleks jika Zustand sudah cukup efisien.
   - **Client Fetching / Axios**: Manfaatkan hanya instance axios yang ada di `src/lib/api/client.ts`. Letakkan interface API response/request kamu di dalam `src/types/api.ts` sehingga type-safety tetap terjaga.

## Apa yang Harus Dilakukan AI Assistant Saat Diberi Instruksi
- Jika user memerintah "buat halaman X", langkah pertama adalah cek tabel rute yang disepakati di `ARSITEKTUR.md`. Letakkan file tersebut di route group yang benar (`(user)` vs `mentor`) sehingga terlindungi dengan layout yang tepat.
- Selalu patuhi strict mode TypeScript. Hindari type `any` bagaimanapun caranya.
- Utamakan User Experience: Dalam proses asinkron (misal upload atau simpan data), selalu sediakan mekanisme loading/spinner dan umpan balik toast (berhasil/gagal).
