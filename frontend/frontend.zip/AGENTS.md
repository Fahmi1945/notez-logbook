<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
<!-- END:nextjs-agent-rules -->

# Aturan Tambahan untuk AI Agents (NOTEZ Frontend)

Saat mengembangkan frontend aplikasi NOTEZ ini, semua AI Agents (GitHub Copilot, Cursor, Claude, dsb.) HARUS membaca dan mengikuti panduan di bawah ini agar sejalan dengan arah teknis (vibe) pengembangan:

## 1. Arsitektur dan Routing
- **Selalu patuhi `ARSITEKTUR.md`**. File tersebut adalah sumber kebenaran (Source of Truth) untuk struktur folder dan rute (URL).
- Gunakan **Next.js App Router** (`src/app`). Jangan gunakan struktur Pages Router.
- Pahami pembagian rute UI:
  - `(auth)`: Route group untuk otentikasi (tanpa sidebar/navbar utama).
  - `(user)`: Route group terproteksi untuk mahasiswa (dengan sidebar role mahasiswa).
  - `mentor`: Rute terproteksi untuk sub-path mentor (dengan sidebar khusus role mentor).
- Otorisasi halaman (Auth Guard) ada di `src/middleware.ts` berbasis Edge Runtime dan token JWT (`jose`). Cukup pertahankan dan ikuti logika middleware yang sudah ada.

## 2. Praktik Komponen (Component Practices)
- **Server Components by Default**: Semua komponen dalam `src/app` adalah Server Components secara default. Hanya gunakan direktif `"use client"` di bagian terujung UI (leaf components) yang membutuhkan interaktivitas (onClick, useState, form hooks, browser API).
- **Shared UI**: Gunakan selalu komponen primitif yang tersedia di `src/components/ui/` (seperti Button, Input, Modal, dll.) sebelum membuat yang baru, guna menjaga konsistensi.
- **Konsistensi Desain**: Proyek ini menggunakan **Tailwind CSS**. Terapkan desain modern yang profesional dengan palet warna slate (sebagai background base) dan warna utama ink-blue. Lihat `src/app/globals.css` untuk melihat panduan variabel CSS/Design Token.

## 3. Data Fetching, State & API
- **Pemanggilan API**: Gunakan Axios melalui instance `client.ts` di folder `src/lib/api/` (instance ini telah dilengkapi interceptor untuk attach token dari cookie/header).
- **Validasi Data**: Validasi payload/body dan validasi form selalu menggunakan skema **Zod** di direktori `src/lib/validators/`.
- **Global State**: Untuk sinkronisasi client-state global (seperti Toast notifications, pengaturan sidebar), pakailah **Zustand** yang ada di `src/store/`. Hindari prop-drilling.

## 4. Filosofi Penulisan Kode
- Gunakan TypeScript secara disiplin dan strict. Selalu buat tipe data/interface yang rapi di `src/types/`.
- **Keep it DRY & Modular**: Pecah logika besar. Pindahkan logika formatting/pembantu murni ke `src/lib/utils.ts` dan logika berbasis state ke `src/hooks/`.
- Berikan komentar jelas pada bagian logika otorisasi atau pemrosesan data yang kompleks.
